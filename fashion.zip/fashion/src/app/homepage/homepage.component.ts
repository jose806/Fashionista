import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import {WishlistService} from "../entities/wishlist.service"
import{ProductService} from '../entities/product/product.service'
import {IProduct, Product} from '../entities/product/product.model';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  error: boolean = false;
  products: Array<IProduct> = [];
  @Input() productToDisplay: IProduct = null;
  constructor(private productService:ProductService, private wishlistService:WishlistService) { }
  @Output() createdProduct = new EventEmitter<IProduct>();
  ngOnInit(): void {
    this.loadAll();
  }

  addlist(inname:string):void {
    const found = this.products.find(({name}) => name=== inname);
    console.log(found.name);
    const temp  = new Product(found.name, found.brand,  found.price, found.availability,found.image, null);

    this.wishlistService.create(temp).then((result: IProduct) => {
      if (result === undefined) {
        this.error = true;
      } else {
        this.error = false;
        this.createdProduct.emit(result);
      }
    });
  }

  private loadAll() {
    this.productService
      .get()
      .then((result: Array<IProduct>) => {
        this.products = result;
      });
  }
}
