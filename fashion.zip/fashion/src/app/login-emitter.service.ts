import { Injectable, EventEmitter } from '@angular/core';
import{Subscription} from 'rxjs/internal/Subscription';

@Injectable({
  providedIn: 'root'
})
export class LoginEmitterService {

  invokeAdminLogin = new EventEmitter();
  subsVar: Subscription;

  constructor() { }

  adminLogin(){
    this.invokeAdminLogin.emit()
    console.log('in the emitting')
  }

  
}
