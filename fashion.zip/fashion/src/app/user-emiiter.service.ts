import { Injectable, EventEmitter } from '@angular/core';
import{Subscription} from 'rxjs/internal/Subscription';
@Injectable({
  providedIn: 'root'
})
export class UserEmiiterService {
  invokeUserLogin = new EventEmitter();
  subsVar: Subscription;

  constructor() { }

  userLogin(){
    this.invokeUserLogin.emit()
    console.log('in the emitting')
  }


}
