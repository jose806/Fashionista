import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {IProduct, Product} from '../entities/product/product.model';
import {ProductService} from '../entities/product/product.service';


@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css']
})
export class AdditemComponent implements OnInit {

  productForm: FormGroup;
  name: string = '';
  brand: string = '';
  price: string = '';
  image: string = '';
  availability: string = '';
  error: boolean = false;

  @Output() createdProduct = new EventEmitter<IProduct>();
  constructor(private productService:ProductService) { }

  private initForm() {
    this.productForm = new FormGroup({
      name: new FormControl(this.name, Validators.required),
      brand: new FormControl(this.brand, Validators.required),
      image: new FormControl(this.image, Validators.required),
      price: new FormControl(this.price, Validators.required),
      availability: new FormControl(this.availability, Validators.required)
    });
  }

  onSubmit() {
  console.log(this.productForm.value)
  const product = new Product(this.productForm.value['name'], this.productForm.value['brand'],  this.productForm.value['price'], this.productForm.value['availability'],this.productForm.value['image'], null);
  this.productService.create(product).then((result: IProduct) => {
    if (result === undefined) {
      this.error = true;
    } else {
      this.error = false;
      this.createdProduct.emit(result);
    }
  });
  }


  ngOnInit(): void {
    this.initForm();
 
  }

}
