import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdditemComponent } from './additem/additem.component';
import { DeleteitemComponent } from './deleteitem/deleteitem.component';
import { HomepageComponent } from './homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { WishlistComponent } from './wishlist/wishlist.component';



const routes: Routes = [
  { path: '', redirectTo: '/homepage', pathMatch: 'full' },
  {path:'login', component:LoginComponent},
  {path:'additem', component:AdditemComponent},
  {path:'deleteitem', component:DeleteitemComponent},
  {path: 'homepage', component:HomepageComponent},
  {path: 'register', component:RegisterComponent},
  {path: 'wishlist', component:WishlistComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents =[LoginComponent, AdditemComponent, DeleteitemComponent, 
  HomepageComponent, RegisterComponent, WishlistComponent]
