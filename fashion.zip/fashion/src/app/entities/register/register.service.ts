import { Injectable } from '@angular/core';
import {Http} from '@angular/http';
import {IUser, User} from './user.model';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  private registerUrl = '/api/register'
  constructor(private http:Http) { }

  // Create User
  create(user: User): Promise<IUser> {
    return this.http.post(this.registerUrl, user)
        .toPromise()
        .then(response => response.json())
        .catch(this.error);
}


   // Get Users
   get(): Promise<Array<IUser>> {
    return this.http.get(this.registerUrl)
        .toPromise()
        .then(response => response.json())
        .catch(this.error);
}

 // Error handling
 private error(error: any) {
  let message = (error.message) ? error.message :
      error.status ? `${error.status} - ${error.statusText}` : 'Server error';
  console.error(message);
}
}
