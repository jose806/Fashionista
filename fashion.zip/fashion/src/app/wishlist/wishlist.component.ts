import { Component, Input, OnInit } from '@angular/core';
import {IProduct, Product} from "../entities/product/product.model";
import {WishlistService} from '../entities/wishlist.service'
@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  products: Array<IProduct> = [];
  @Input() productToDisplay: IProduct = null;
  constructor(protected wishlistService: WishlistService) { }
 // Load all the products when starting the view.
 ngOnInit(): void {
  this.loadAll();
 
}

// If new product created, we add it to the list.
ngOnChanges(): void {
  if (this.productToDisplay !== null) {
    this.products.push(this.productToDisplay);
  }
}

// Delete a product. 
delete(id: string) {
  this.wishlistService.delete(id).then((result: any) => this.loadAll());
  console.log('in delete method')
}

// Load all products.
private loadAll() {
  this.wishlistService
    .get()
    .then((result: Array<IProduct>) => {
      this.products = result;
    });
}

}
