import { TestBed } from '@angular/core/testing';

import { UserEmiiterService } from './user-emiiter.service';

describe('UserEmiiterService', () => {
  let service: UserEmiiterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserEmiiterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
