import { Injectable } from '@angular/core';
import{HeaderComponent} from './header/header.component'

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  uname:string = 'admin';
  upassword:string = 'admin123';
  header:HeaderComponent;
  constructor() { }

  login(data:any){
    console.log(data.uname)
    

    if(this.uname == data.uname &&  this.upassword == data.upassword){
      console.log("right admin")
      return true;
    }

  }
}
