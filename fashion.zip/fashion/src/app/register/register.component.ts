import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {RegisterService} from '../entities/register/register.service'
import{IUser, User} from '../entities/register/user.model'

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  name: string = '';
  email: string = '';
  password: string = '';
  error: boolean = false;

  @Output() createdUser = new EventEmitter<IUser>();
  constructor(private registerService:RegisterService) { }

  ngOnInit(): void {
    this.initForm();
  }

  initForm(){
    this.registerForm = new FormGroup({
      name: new FormControl(this.name, Validators.required),
      email: new FormControl(this.name, Validators.required),
      password: new FormControl(this.password, Validators.required),
    })
  }

  onSubmit(){
    console.log(this.registerForm.value)
    const user = new User(this.registerForm.value['name'], this.registerForm.value['email'],  this.registerForm.value['password'],  null);
    this.registerService.create(user).then((result: IUser) => {
      if (result === undefined) {
        this.error = true;
      } else {
        this.error = false;
        this.createdUser.emit(result);
      }
    });
  }

}
