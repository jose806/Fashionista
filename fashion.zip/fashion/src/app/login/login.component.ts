import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {LoginEmitterService} from '../login-emitter.service';
import {IUser} from '../entities/register/user.model';
import {RegisterService} from '../entities/register/register.service';
import{UserEmiiterService} from '../user-emiiter.service'
import { from } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  users: Array<IUser> = [];
  loginForm: FormGroup;
  uname: string = '';
  upassword: string= '';
  constructor(private userEmitterService:UserEmiiterService,private LoginEmitterService: LoginEmitterService, private registerService:RegisterService) { }

  ngOnInit(): void {
    this.initForm();
    this.getallusers();
  }

  onSubmit(){
    console.log(this.loginForm.value)
    this.emitAdminLogin()
    this.getallusers()
    console.log(this.users)
    console.log(this.loginForm.value['uname'])
    var found: IUser = null;
    //found = this.users.find(this.loginForm.value['uname'])
    found = this.users.find(({email}) => email ===this.loginForm.value['uname'] );
    console.log('found is: ' + found)
    if(found.email === this.loginForm.value['uname']){
      this.emitUserLogin()
      console.log("found")
    }
    else{
      this.emitAdminLogin()
    }
    
 
  }
  initForm(){
    this.loginForm = new FormGroup({
      uname: new FormControl(this.uname, Validators.required),
      upassword: new FormControl(this.upassword, Validators.required)
    })
  }

  emitAdminLogin(){
    console.log("in emiter function")
    this.LoginEmitterService.adminLogin();
  }
  emitUserLogin(){
    this.userEmitterService.userLogin();
  }
 

  getallusers(){
    this.registerService
      .get()
      .then((result: Array<IUser>)=>{
        this.users = result;
      })
  }
}
