import { Component, OnInit } from '@angular/core';
import {LoginEmitterService} from "../login-emitter.service"
import {UserEmiiterService} from '../user-emiiter.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  isAdmin:boolean = false;
  isUser:boolean = false;
  loggedIn:boolean = false;

  constructor(private loginEmitterService:LoginEmitterService, private userEmitterService:UserEmiiterService) { }

  ngOnInit(): void {
    if(this.loginEmitterService.subsVar == undefined){
      this.loginEmitterService.subsVar = this.loginEmitterService.invokeAdminLogin.subscribe(()=>{
        this.loginAdmin()
      })
    }
   else if(this.userEmitterService.subsVar == undefined){
      this.userEmitterService.subsVar = this.userEmitterService.invokeUserLogin.subscribe(()=>{
        this.loginUser()
      })
    }
  }

  loginAdmin():void{
    this.isAdmin = true;
    this.loggedIn = true;
  }

  loginUser():void{
    this.isUser = true;
    this.loggedIn = true;
  }
  
  logout():void{
    this.isAdmin = false;
    this.loggedIn = false;
    this.isUser = false;
  }


}
